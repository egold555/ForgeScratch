/**
 * All the block base classes
 */
/**
 * @author Eric
 *
 */
package org.golde.forge.scratchforge.base.common.block;