/**
 * Helper classes for both server and client
 */
/**
 * @author Eric
 *
 */
package org.golde.forge.scratchforge.base.helpers;