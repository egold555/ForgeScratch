package org.golde.forge.scratchforge.base.helpers;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Random;

import javax.net.ssl.HttpsURLConnection;

public class JavaHelpers {

	public static final Random RANDOM = new Random();
	
	public static Field getField(Class<?> clazz, String fieldName) throws RuntimeException{
		Class<?> tmpClass = clazz;
		do {
			try {
				Field f = tmpClass.getDeclaredField(fieldName);
				return f;
			} catch (NoSuchFieldException e) {
				tmpClass = tmpClass.getSuperclass();
			}
		} while (tmpClass != null);

		throw new RuntimeException("Field '" + fieldName + "' not found on class " + clazz);
	}

	public static String joinStrings(List<String> list, String conjunction, int iequals)
	{
		StringBuilder sb = new StringBuilder();
		boolean first = true;
		for(int i = iequals; i < list.size(); ++i)
		{
			String item = list.get(i);

			if (first)
				first = false;
			else
				sb.append(conjunction);
			sb.append(item);
		}
		return sb.toString();
	}

	public static String makeJavaId(String name) {
		String result = "";
		for (int i = 0; i < name.length(); ++i) {
			char c = name.charAt(i);
			if (isJavaId(c)) {
				result = result + c;
			}
			else {
				result = result + "_";
			}
		}

		return result.toLowerCase();
	}

	public static boolean isJavaId(char c) {
		if (c >= 'A' && c <= 'Z')
			return true;
		else if (c >= 'a' && c <= 'z') 
			return true;
		else if (c >= '0' && c <= '9') 
			return true;

		return false;
	}

	public static int hexToMinecraftColor(String hex) {
		hex = hex.replace("#", "");
		return (int) Long.parseLong(hex, 16);
	}

	public static void sendRequest(String ip, String args, String getOrPost) {

		new Runnable() {

			@Override
			public void run() {
				int code = 0;
				try {
					if(getOrPost.equals("GET")) {
						code = sendGetRequest(ip);
					}
					else {
						code =  sendPostRequest(ip, args);
					}
				}
				catch(Exception e) {
					PLog.error(e, "Failed to send HTTP Request");
					return;
				}
				if(code != 200) {
					PLog.warning("Status code returned was: " + code + "! Expecting a 200 responce.");
				}
			}

		}.run();


	}

	private static int sendPostRequest(String url, String urlParameters) throws Exception{
		URL obj = new URL(url);
		HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

		//add reuqest header
		con.setRequestMethod("POST");
		con.setRequestProperty("User-Agent", "Mozilla/5.0");
		con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

		// Send post request
		con.setDoOutput(true);
		DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		if(urlParameters != null && !urlParameters.equals("null")) {
			wr.writeBytes(urlParameters);
		}
		wr.flush();
		wr.close();

		int responseCode = con.getResponseCode();
		//PLog.info("\nSending 'POST' request to URL : " + url);
		//PLog.info("Post parameters : " + urlParameters);
		//PLog.info("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(
				new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		return responseCode;
	}

	private static int sendGetRequest(String url) throws Exception{

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// optional default is GET
		con.setRequestMethod("GET");

		//add request header
		con.setRequestProperty("User-Agent", "Mozilla/5.0");

		int responseCode = con.getResponseCode();
		//PLog.info("\nSending 'GET' request to URL : " + url);
		//PLog.info("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(
				new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		return responseCode;
	}

}
