/**
 * All the world generation base classes
 */
/**
 * @author Eric
 *
 */
package org.golde.forge.scratchforge.base.common.world;