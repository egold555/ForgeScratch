/**
 * These models are models for classes that cast to a specific entity
 * This makes it so anyone can use these models without extending the entity
 */
/**
 * @author Eric
 *
 */
package org.golde.forge.scratchforge.base.client.models;