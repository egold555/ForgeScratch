/**
 * These classes are all Server base classes
 */
/**
 * @author Eric
 *
 */
package org.golde.forge.scratchforge.base.common;