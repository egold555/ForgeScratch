package org.golde.forge.scratchforge.base.common.world;

import net.minecraft.entity.EntityLiving;
import net.minecraft.nbt.NBTTagCompound;

public class VariableHolder {
	public EntityLiving entity;
	public NBTTagCompound nbt;
}