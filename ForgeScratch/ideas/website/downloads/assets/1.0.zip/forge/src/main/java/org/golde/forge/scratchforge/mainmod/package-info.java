/**
 * The main scratchforge mod.
 * This makes new gui screens to improve user experience
 * Not neeeded for mod releases
 */
/**
 * @author Eric
 *
 */
package org.golde.forge.scratchforge.mainmod;