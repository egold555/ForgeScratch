/**
 * These classes are all Client base classes
 */
/**
 * @author Eric
 *
 */
package org.golde.forge.scratchforge.base.client;